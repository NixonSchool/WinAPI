// simplewall
// Copyright (c) 2016-2023 Henry++

#pragma once

#define APP_NAME L"simplewall"
#define APP_NAME_SHORT L"simplewall"
#define APP_VERSION L"3.7.1"
#define APP_VERSION_RES 3,7,1,0
#define APP_AUTHOR L"Henry++"
#define APP_COPYRIGHT L"(c) 2016-2023 " APP_AUTHOR L". All Rights Reversed."
